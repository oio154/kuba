<?PHP
    $server = 'localhost';
    $username = 'ajax';
    $password = 'Dupa1234';
    $db = 'ajax';

    $conn = mysqli_connect($server, $username, $password, $db);
?>