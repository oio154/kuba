<?php
session_start();
?>



<?php
  //  $_SESSION['userid']='666';
?>






psoijfoijfdoidj




<?php
    $r = "INSERT INTO wiadomosci values(null,'osdijfsodifjosidjfds','{$_SESSION['userid']}')";
    
    echo($r);
?>